using System;

namespace Encoder
{
    public class EncoderProcessor
    {
      
        public string Encode(string message)
        {
            message = message.ToLower();
            //Implement your code here!
            var vowelarray = new char[] { 'a', 'e', 'i', 'o', 'u' };
            string encodestr = "";
            bool isNumeric = false;
            string numstr="";
            for(int i = 0; i < message.Length; i++)
            {
              bool isNum=  Char.IsNumber(message[i]);
                char con = (char)(message[i] - 1);
                bool isspecial = !Char.IsLetterOrDigit(message[i]);
                int vowelind = Array.IndexOf(vowelarray, message[i]);
                if(isNumeric && !isNum)
                {
                    encodestr += ReverseNum(Convert.ToInt32(numstr)).ToString();
                    isNumeric = false;
                    numstr = "";
                }
                if (vowelind> -1){
                    encodestr += vowelind + 1;
                }
                else if (isNum)
                {
                    isNumeric = true;
                    numstr += message[i];
                    if (i == message.Length - 1)
                    {
                        encodestr += ReverseNum(Convert.ToInt32(numstr)).ToString();
                    }
                 // encodestr+=  ReverseNum((int)Char.GetNumericValue(message[i]), 0, 1).ToString();
                }
                else if(Char.IsWhiteSpace(message[i]))
                {
                    encodestr += 'y';
                }
                else if (message[i] == 'y')
                {
                    encodestr += " ";
                }
                else if (isspecial)
                {
                    encodestr += message[i];
                }
                else
                {
                    encodestr += con;
                }
            }


            return encodestr;
        }

        public static int ReverseNum(int num)
        {
            int reverse = 0;
            while (num > 0)
            {
                int remainder = num % 10;
                reverse = (reverse * 10) + remainder;
                num = num / 10;
            }

            return reverse;
        }

     
    }
}